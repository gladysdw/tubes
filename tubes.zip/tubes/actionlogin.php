<?php
   session_start();
   $conn = mysqli_connect ("sql108.epizy.com", "epiz_23895109", "46H0J0Bz", "epiz_23895109_ycdys");
   require_once("koneksi.php");
   $username = $_POST['username'];
   $pass = md5($_POST['password']);   
   $sql = "SELECT * FROM user WHERE username = '$username'";
   $query = $conn ->query($sql);
   $hasil = $query->fetch_assoc();
   
if($query->num_rows == 0) {
     echo "<div align='center'>Username Belum Terdaftar! <a href='regis.php'>Back</a></div>";
   } else {
     if($pass <> $hasil['password']) {
       echo "<div align='center'>Password salah! <a href='login.php'>Back</a></div>";
     } else {
       $_SESSION['username'] = $hasil['username'];
       $_SESSION['level'] = $hasil['level'];
       if ($hasil['level']=="Admin") {   
           header("location:home.php");
        }
      else if ($hasil['level']=="User"){
            header("location:homeuser.php");
      }
     }
   }

?>