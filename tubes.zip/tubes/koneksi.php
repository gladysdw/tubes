<?php

$conn = mysqli_connect ("sql108.epizy.com", "epiz_23895109", "46H0J0Bz", "epiz_23895109_ycdys");

?>